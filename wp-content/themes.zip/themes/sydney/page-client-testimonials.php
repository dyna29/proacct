<?php
/**
 * Template Name: Template testimonials
 *
 * @package 
 */ 

get_header(); ?>
<style>
.testimonial-item:before {
    display: block;
    content: " ";
    margin-top: -200px;
    height: 200px;
    visibility: hidden;
    pointer-events: none;
}
</style>
	<div id="primary" class="content-area col-md-12 inner-testimonials">
		<main id="main" class="post-wrap" role="main">
 <header class="entry-header">
		<h1 class="title-post entry-title">What Our Clients Say</h1>	</header>
			<?php 
					$args = array(	'post_type' => 'testimonials',
					'posts_per_page' => -1, 
					'orderby'   => 'ID',
					'order' => 'DESC',
					);
					$loop = new WP_Query($args);
					$i=0;
					if($loop->have_posts()) {
						while($loop->have_posts()) : $loop->the_post();
						
						$sydney_toolbox_client_info = get_post_meta(get_the_ID(),'wpcf-client-function',true);
							$featuredimage = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), 'full' ); 
						?>
	 <div class="row testimonial-item" id="testimonial-<?php echo get_the_ID();?>">
		
		 <div class="col-md-12 testimonial-title">
		 <span class="client-name"><?php the_title();
			 ?></span>
			 
			<br><span><?php echo $sydney_toolbox_client_info;
			 ?></span>
		 </div>
		  <div class="col-md-12 testimonial-img">
			 <img src="<?php echo $featuredimage [0]?>" width="150" height="150">
		 </div>
		 <div class="col-md-12 testimonial-content">
		 <?php the_content();
			 ?>
			
		 </div>
		 </div>
					 
			  <?php
						
							$i++;
						endwhile;
						wp_reset_postdata();
					} ?>

		</main><!-- #main -->
	</div><!-- #primary -->

 
<?php get_footer(); ?>