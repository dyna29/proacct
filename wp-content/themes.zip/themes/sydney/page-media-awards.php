<?php
 /*

Template Name: Media Awards

*/
	get_header();
?>

 
	<div id="primary" class="content-area">
		<main id="main" class="site-main zoom-gallery" role="main">
<article id="post-520" class="post-520 page type-page status-publish hentry">
	<header class="entry-header">
		<h1 class="title-post entry-title"><?php the_title();?></h1></header>
				<?php 
					$args = array(	'post_type' => 'media-content',
					'posts_per_page' => -1, 
					'orderby'   => 'ID',
					'order' => 'ASC',
					);
					$loop = new WP_Query($args);
					$i=0;
					if($loop->have_posts()) {
						while($loop->have_posts()) : $loop->the_post();
							$i++;
							$featuredimage = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), 'full' );  
							?><div class="row media-awards-row">
	<div class="col-md-4">
		<a href="<?php echo $featuredimage[0]; ?>" style="cursor: zoom-in;"><img src="<?php echo $featuredimage[0]; ?>"></a>
	</div>
	
	<div class="col-md-8">
		
		<h2 id="our-vision" class="title-post entry-title inner-sub-title media-awards" style="color: rgb(68, 63, 63);"><?php the_title(); ?></h2>
		<p>
			<?php the_content(); ?>
		</p>
	</div></div>

				<?php
						endwhile;
						wp_reset_postdata();
					} ?>
			</article>
		</main><!-- #main -->
	</div><!-- #primary -->

<?php get_footer(); ?>
<script> 
	jQuery(document).on('ready', function () {
  jQuery('.zoom-gallery').magnificPopup({
    delegate: 'a',
    type: 'image',
    closeOnContentClick: false,
    closeBtnInside: false,
    mainClass: 'mfp-with-zoom mfp-img-mobile',
    image: {
      verticalFit: true,
      titleSrc: function (item) {

      }
    },
    gallery: {
      enabled: true
    },
    zoom: {
      enabled: true,
      duration: 300, // don't foget to change the duration also in CSS
      opener: function (element) {
        return element.find('img');
      }
    }

  });
		
  });
</script>