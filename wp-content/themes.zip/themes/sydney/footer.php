<?php
/**
 * The template for displaying the footer.
 *
 * Contains the closing of the #content div and all content after
 *
 * @package Sydney
 */
?>
			</div>
		</div>
	</div><!-- #content -->
<?php 
							$contact_query = new WP_Query( array( 'pagename' => 'contact' ) );
							while($contact_query->have_posts()): $contact_query->the_post();  
								$facebook_link = get_post_meta($post->ID, 'facebook_link', true);
								$twitter_link = get_post_meta($post->ID, 'twitter_link', true);
								$linkedin_link = get_post_meta($post->ID, 'linkedin_link', true);
								$google_plus_link= get_post_meta($post->ID, 'google_plus_link', true); 
								$youtube_link = get_post_meta($post->ID, 'youtube_link', true); 
								$instagram_link = get_post_meta($post->ID, 'instagram_link', true); 
								$brochure = get_post_meta($post->ID, 'brochure', true); 
								 
							endwhile;  
										 
							wp_reset_postdata();
							?>
	<?php do_action('sydney_before_footer'); ?>

	<?php if ( is_active_sidebar( 'footer-1' ) ) : ?>
		<?php get_sidebar('footer'); ?>
	<?php endif; ?>

    <a class="go-top"><i class="fa fa-angle-up"></i></a>
		<div class="social-footer siteorigin-panels-stretch panel-row-style panel-row-style-for-466-7" style="color: rgb(255, 255, 255); padding: 50px 104.5px;  border-left: 0px; border-right: 0px; background-position: 50% 222px;" data-stretch-type="full" data-hascolor="hascolor" data-overlay="true"><div id="pgc-466-7-0" class="panel-grid-cell" style="color: inherit;"><div id="panel-466-7-0-0" class="so-panel widget widget_fp_social panel-first-child panel-last-child" data-index="9" style="color: inherit;"><div style="text-align: left; color: inherit;" data-title-color="#443f3f" data-headings-color="#443f3f" class="panel-widget-style panel-widget-style-for-466-7-0-0">						<div class="menu-social-container" style="color: inherit;"><ul id="menu-social" class="menu social-menu-widget clearfix"><li id="menu-item-64" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-64"><a href="<?php echo $facebook_link; ?>" style="color: inherit;" target="_blank"><span class="screen-reader-text" style="color: inherit;">Fb</span></a></li>
<li id="menu-item-65" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-65"><a href="<?php echo $twitter_link; ?>" style="color: inherit;" target="_blank"><span class="screen-reader-text" style="color: inherit;">Twitter</span></a></li> 
<li id="menu-item-67" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-67"><a href="<?php echo $instagram_link; ?>" style="color: inherit;" target="_blank"><span class="screen-reader-text" style="color: inherit;">Instagram</span></a></li>
<li id="menu-item-68" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-68"><a href="<?php echo $linkedin_link; ?>" style="color: inherit;" target="_blank"><span class="screen-reader-text" style="color: inherit;">Linkedin</span></a></li>
<li id="menu-item-149" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-149"><a href="<?php echo $youtube_link; ?>" style="color: inherit;" target="_blank"><span class="screen-reader-text" style="color: inherit;">Youtube</span></a></li>
</ul></div>	
		</div></div></div></div>
	<footer id="colophon" class="site-footer" role="contentinfo">
		<div class="site-info container">
			<a href="<?php echo esc_url( __( 'http://kdakw.com/', 'sydney' ) ); ?>" target='_blank'><?php printf( __( 'Powered by %s', 'sydney' ), 'KDA' ); ?></a>
		 
		</div><!-- .site-info -->
	</footer><!-- #colophon -->

	<?php do_action('sydney_after_footer'); ?>

</div><!-- #page -->

<?php wp_footer(); ?>
<script> jQuery(document).ready(function() {
		 jQuery('.contact-brocure').html('<i class="fa fa-file-pdf-o"></i><?php echo $brochure;?>')
		 jQuery('.contact-brocure').find('a').attr("target","_blank")
	 
		if(jQuery('#cf-specialization').length>0){
			 jQuery('#cf-specialization option:first').text('Select area of specialization');
		}
		if(jQuery('#cf-category').length>0){
			 jQuery('#cf-category option:first').text('Select category');
		}
		jQuery( "#home-testimonials .widget-title" ).click(function() {
location.href="<?php echo site_url(); ?>/what-our-clients-associates-say/"
});
		
		
		jQuery( "#home-testimonials p" ).click(function() {
			ind = jQuery(this).closest('.owl-item').index();
            location.href="<?php echo site_url(); ?>/what-our-clients-associates-say/#testimonial-"+ind
        });
			jQuery( "#home-referral-network a" ).attr("href","<?php echo site_url('/referral-network/'); ?>");
 
		
	})
 
        
      
 


	</script>
</body>
</html>
